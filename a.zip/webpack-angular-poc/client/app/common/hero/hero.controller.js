class HeroController {
  constructor() {
    this.name = 'hero';
  }
}

export default HeroController;
