import template from './app.html';
import './app.styl';

const appComponent = {
  template,
  restrict: 'E',
};

export default appComponent;
