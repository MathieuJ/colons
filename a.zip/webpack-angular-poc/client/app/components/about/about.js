import angular from 'angular';
import uiRouter from 'angular-ui-router';
import ocLazyLoad from 'oclazyload';

const aboutModule = angular.module('about', [uiRouter, ocLazyLoad])

  .config(($stateProvider, $compileProvider) => {
    'ngInject';
    $stateProvider
      .state('about', {
        url: '/about',
        template: '<about></about>',

        // Lazy load this component
        resolve: {
          loadComponent: ($q, $ocLazyLoad) => {
            const deferred = $q.defer();

            // Webpack will define a code-split point for all requires in this callback
            // This will effectively bundle this entire module into a single file
            // that only gets downloaded when this state is transitioned to
            require.ensure([], (require) => {
              // Require our modules
              // This replaces the `import` statements from above
              // const something = require('./about.something');
              // .. any other dependencies
              const component = require('./about.component');

              // Inject all dependencies into our module
              // This replaces adding them to the original angular.module dependency array
              // ie using something.name

              $ocLazyLoad.inject([])

                // Register the component so the template recognizes it
                .then(() => $compileProvider.component('about', component))

                // Continue the state transition
                .then(deferred.resolve);
            }, 'about'); // Name our bundle so it shows up pretty in the network tab

            return deferred.promise;
          },
        },
      });
  });

export default aboutModule;
