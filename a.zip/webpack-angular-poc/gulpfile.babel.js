/* esLint no-console: off */
/* eslint-plugin-disable angular */

import gulp     from 'gulp';
import eslint   from 'gulp-eslint';
import webpack  from 'webpack';
import path     from 'path';
// import sync     from 'run-sequence';
import rename   from 'gulp-rename';
import template from 'gulp-template';
import yargs    from 'yargs';
import gutil    from 'gulp-util';
import serve    from 'browser-sync';
import webpackDevMiddelware from 'webpack-dev-middleware';
import webpachHotMiddelware from 'webpack-hot-middleware';
import colorsSupported      from 'supports-color';
import historyApiFallback   from 'connect-history-api-fallback';
import minimist from 'minimist';
import pad from 'node-string-pad';
import merge from 'merge';
import fs from 'fs';
import q from 'q';

(function () {
  const root = 'client';

// helper method for resolving paths
// app/{glob}
  const resolveToApp = (glob = '') => path.join(root, 'app', glob);

// app/components/{glob}
  const resolveToComponents = (glob = '') => path.join(root, 'app/components', glob);

  const getCmdOptions = () => minimist(process.argv.slice(2));

  /**
   * Return oic config with command line params parsed
   * @returns {{oic: {}}}
   */
  const getOicRunOptions = (options) => {
    const cmdRunOptions = {
      oic: {},
    };

    if (options.custom) {
      const customParam = options.custom.toString();
      cmdRunOptions.oic.custom = pad(customParam, 3, 'LEFT', '0');
    }

    console.log('GULP CMD OPTIONS : ', cmdRunOptions);

    return cmdRunOptions;
  };

  /**
   * Inject the @import to the .styl file according the 'custom' option
   * @param config
   */
  const setOicCustomStyle = (custom) => {
    const customFile = 'client/app/styles/custom/custom.styl';
    // clean custom.styl
    fs.writeFile(customFile, '');

    if (custom) {
      fs.writeFile(customFile, `@import '${custom}'`);
    }
  };

  /**
   * Set OIC build according oic config
   * @param config
   */
  const setOicBuild = (config) => {
    if (config) {
      setOicCustomStyle(config.custom);
    }
  };

  /**
   * get custom code from custom/xxx.styl name
   * @param customFileName
   * @returns {*}
   */
  const getCustomCode = (customFileName) => {
    let customCode = null;
    const customMatch = customFileName.match(/(.*)\.styl$/);
    if (Array.isArray(customMatch) && customMatch[1] !== 'custom') {
      customCode = customMatch[1];
    }
    return customCode;
  };

  /**
   * Initialise webpack config according environement
   * @param tagConfigPath
   * @returns {*}
   */
  const initTaskWebpackConfig = (tagConfigPath, cmdOpts) => {
    let config;
    const cmdOptions = cmdOpts || getCmdOptions();

    config = require(tagConfigPath);  // eslint-disable-line global-require
    // application entry point
    config.entry.app = [];
    config.entry.app.push(paths.entry);
    config = merge(config, getOicRunOptions(cmdOptions));
    setOicBuild(config.oic);

    return config;
  };


  const buildCustom = (customFileList, i) => {
    let customCode;
    let config;
    const deffered = q.defer();


    if (customFileList[i]) {
      customCode = getCustomCode(customFileList[i]);
      if (customCode) {
        console.log('Running build for ', customCode, '...');
        config = initTaskWebpackConfig('./webpack.dist.config', { custom: customCode });
        config.output.path = path.resolve(__dirname, `dist/${customCode}`);
        runWebpackTask(config).then(() => {
          console.log('...', customCode, ' done\n\n');
          buildCustom(customFileList, i + 1).then(() => {
            deffered.resolve();
          });
        });
      } else {
        // run next custom build without running webpack build
        buildCustom(customFileList, i + 1).then(() => {
          deffered.resolve();
        });
      }
      // end of the file list in custom dir
    } else {
      console.log('>> Fin de la liste');
      deffered.resolve();
    }
    return deffered.promise;
  };

  const runWebpackTask = (config) => {
    const deffered = q.defer();

    webpack(config, (err, stats) => {
      if (err) {
        throw new gutil.PluginError('webpack', err);
      }

      gutil.log('[webpack]', stats.toString({
        colors: colorsSupported,
        chunks: false,
        errorDetails: true,
      }));
      deffered.resolve();
    });
    return deffered.promise;
  };

// map of all paths
  const paths = {
    js: resolveToComponents('**/*!(.spec.js).js'), // exclude spec files
    styl: resolveToApp('**/*.styl'), // stylesheets
    html: [
      resolveToApp('**/*.html'),
      path.join(root, 'index.html'),
    ],
    entry: path.join(__dirname, root, 'app/app.js'),
    output: root,
    blankTemplates: path.join(__dirname, 'generator', 'component/**/*.**'),
  };

// use webpack.config.js to build modules
  gulp.task('webpack', (cb) => {
    const config = initTaskWebpackConfig('./webpack.dist.config');
    runWebpackTask(config, cb);
  });

  gulp.task('serve', () => {
    const config = initTaskWebpackConfig('./webpack.dev.config');
    // this modules required to make HRM working
    // it responsible for all this webpack magic
    config.entry.app.push('webpack-hot-middleware/client?reload=true');

    console.log('WEBPACK CONFIG DEV', config);

    const compiler = webpack(config);
    serve({
      port: process.env.PORT || 3000,
      open: false,
      server: { baseDir: root },
      middleware: [
        historyApiFallback(),
        webpackDevMiddelware(compiler, {
          stats: {
            colors: colorsSupported,
            chunks: false,
            modules: false,
          },
          publicPath: config.output.publicPath,
        }),
        webpachHotMiddelware(compiler),
      ],
    });
  });

  gulp.task('build-all', (cb) => {
    const dirs = fs.readdirSync('client/app/styles/custom');

    buildCustom(dirs, 0).then(() => {
        cb();
    });
  });

  gulp.task('lint', () =>
    // ESLint ignores files with "node_modules" paths.
    // So, it's best to have gulp ignore the directory as well.
    // Also, Be sure to return the stream from the task;
    // Otherwise, the task may end before the stream has finished.
    gulp.src(['**/*.js', '!node_modules/**', '!dist/**'])
    // eslint() attaches the lint output to the "eslint" property
    // of the file object so it can be used by other modules.
      .pipe(eslint())
      // eslint.format() outputs the lint results to the console.
      // Alternatively use eslint.formatEach() (see Docs).
      .pipe(eslint.format())
      // To have the process exit with an error code (1) on
      // lint error, return the stream and pipe to failAfterError last.
      .pipe(eslint.failAfterError())
  );


  gulp.task('watch', ['serve']);

  gulp.task('component', () => {
    const cap = (val) => val.charAt(0).toUpperCase() + val.slice(1);
    const name = yargs.argv.name;
    const parentPath = yargs.argv.parent || '';
    const destPath = path.join(resolveToComponents(), parentPath, name);

    return gulp.src(paths.blankTemplates)
      .pipe(template({
        name,
        upCaseName: cap(name),
      }))
      .pipe(rename(() => {
        path.basename = path.basename.replace('temp', name);
      }))
      .pipe(gulp.dest(destPath));
  });

  gulp.task('default', ['serve']);
}());
