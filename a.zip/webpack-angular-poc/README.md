# POC Webpack Angular

## NG6-starter

Ce poc "webpack angular" est basé sur [NG6-starter](https://github.com/AngularClass/NG6-starter).

NG6-starter permet, via Angular 1.x, Webpack 1.x et ES6, d'initier une application proposant : 

* Une structure de dossiers/fichiers basée sur les "best practices" pour Angular (pour gérer toute taille d'application)
* Un système de build basé sur ES6 (via Babel)
* Un générateur de ["component" Angular](https://docs.angularjs.org/guide/component) (>= Angular 1.5)
* Un système complet de test unitaire
* Le support de [Stylus](http://stylus-lang.com/)


## Objectif du POC
 
La première étape consiste à s'approprier la stack Webpack/Angular.

Ensuite, dans le cadre du projet OIC Mobile 2.x, à partir de NG6-starter, il s'agit de valider la mise en place de certains besoins :

* [x] Lazyloading : à partir de routes simples, tester le chargement dynamique des différents modules Angular (via ~~Components/Component Router~~ ocLazyload https://github.com/AngularClass/NG6-starter/wiki/Lazy-Loading ).
~~Remplacer angular-ui-router par ngComponentRouter (plus proche d'Angular 2)~~ (component router est trop instable encore)
Surveiller cette feature annoncée pour Angular 1.6 https://github.com/angular/angular.js/pull/4694
* [] ~~optimiser la taille de vendor.bundle.js (actuellement 1.5 MB)~~ En fait c'est la taille de la version DEV. La taille optimisée elle fait moins de 250kB actuellement. De plus si on cherche à optimiser cette taille, en fait le code se retrouve dans app.bundle.js et peut donc pénaliser le chargement initial de la page (pour gérer le FOUC par ex.). Après vérification, les 1.5 MB sont cohérent, les sources d'angular font déjà 1.09Mo...

* [x] Couverture de code (Karma coverage)
* [x] Linting : ESLINT (Airbnb + Angularjs - [Johnpapa style](https://github.com/johnpapa/angular-styleguide/tree/master/a1) cf. aussi http://survivejs.com/webpack_react/linting_in_webpack/
* [x] Phantomjs pour les TU (au lieu de Chrome par défaut)
* [] ~~Remplacer~~ Valider le support Stylus ~~par~~ vs SASS (syntaxe en particulier...)
    * [x] Intégrer Bootstrap [Bootstrap/Stylus](https://github.com/maxmx/bootstrap-stylus)
    * [x] Gérer les variables (Bootstrap/Stylus) pour les différentes enseignes
    lancez la commande `gulp serve --custom=001 ou 002` et regardez les boutons changer de couleur
* [x] Marque blanche : générer des builds en fonction d'une charte spécifique
    * [x] Gérer les commandes `gulp serve` avec option "custom" (ie. `gulp serve --custom=001`)
    * [x] Gérer le build pour toutes les enseignes (commande `gulp build-all`)
* [] (optionnel) Implémenter la génération auto de doc CSS (via [KSS](https://github.com/kss-node/kss-node) ?)
* [x] Mettre à jour les modules avec les dernières versions compatibles avec NG6-starter

## Notes

* http://jamesknelson.com/teaching-gulp-es6-with-babel-6/ : permet de configurer correctement Babel pour éviter une erreur levée dans Gulp sur les "import" (SyntaxError : Unexpected reserved word)
* Stylus (vs LESS/SASS) : 
    * http://code.tutsplus.com/tutorials/sass-vs-less-vs-stylus-preprocessor-shootout--net-24320, 
    * http://webdesign.tutsplus.com/articles/why-i-choose-stylus-and-you-should-too--webdesign-18412, 
    * http://www.webdesignermag.co.uk/sass-v-less-v-stylus-the-pros-and-cons/
    * PROS :
        * Pas de dépendance à un binaire, ce n'est que du Javascript (donc moins sensible à la sécurité réseau) donc très adapté à l'environnement Node.js
        * Stylus est entièrement scriptable (en plus de gérer les classques variables, mixin etc... il existe une API Javascript) donc très adapté au contexte de marque blanche
        * Stylus permet d'écrire le CSS sans accolades, point-virgules etc... en utilisant uniquement indentations et sauts de ligne mais, si on est plus à l'aise avec ces éléments structurant, on peut aussi écrire le code CSS avec la syntaxe standard.
        * Il existe un portage de [Bootstrap en Stylus](https://github.com/maxmx/bootstrap-stylus)  (à priori à jour avec l'intention de porter Bootstrap 4 quand la version sera plus avancée - actuellement en version alpha - )
        * Fourni sa propre solution pour le support CSS3 des anciens navigateurs
    * CONS :
        * Moins connus que SASS mais mieux considéré que LESS (bien pour s'initier aux préprocesseurs CSS mais limité)
        * Plus complexe que LESS mais moins que SASS si on prend compte le fait de ne pas avoir à installer RUBY



