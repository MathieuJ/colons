class <%= upCaseName %>Controller {
  constructor() {
    this.name = '<%= name %>';
  }
}

export default <%= upCaseName %>Controller;
